from fastapi import FastAPI, APIRouter, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional
import uuid
from datetime import datetime, timezone, timedelta
from passlib.context import CryptContext
from jose import JWTError, jwt

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# JWT settings
SECRET_KEY = os.environ.get('JWT_SECRET_KEY', 'your-secret-key-change-in-production')
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7  # 7 days

security = HTTPBearer()

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# ==================== Models ====================

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    name: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class User(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: EmailStr
    name: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class TokenResponse(BaseModel):
    token: str
    user: User

class IssueCreate(BaseModel):
    title: str
    description: str
    priority: str  # low, medium, high

class SolutionCreate(BaseModel):
    solution_text: str

class Solution(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    solution_text: str
    created_by: str
    created_by_name: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Issue(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    description: str
    priority: str
    status: str = "open"  # open, in-progress, resolved
    user_id: str
    user_name: str
    solutions: List[Solution] = []
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class IssueUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    priority: Optional[str] = None
    status: Optional[str] = None

# ==================== Helper Functions ====================

def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

def create_access_token(data: dict) -> str:
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)) -> dict:
    token = credentials.credentials
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Invalid token")
        
        user = await db.users.find_one({"id": user_id}, {"_id": 0})
        if user is None:
            raise HTTPException(status_code=401, detail="User not found")
        return user
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

# ==================== Auth Routes ====================

@api_router.post("/auth/register", response_model=TokenResponse)
async def register(user_data: UserCreate):
    # Check if user already exists
    existing_user = await db.users.find_one({"email": user_data.email}, {"_id": 0})
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Create new user
    user = User(
        email=user_data.email,
        name=user_data.name
    )
    
    user_dict = user.model_dump()
    user_dict['password_hash'] = hash_password(user_data.password)
    user_dict['created_at'] = user_dict['created_at'].isoformat()
    
    await db.users.insert_one(user_dict)
    
    # Create access token
    access_token = create_access_token(data={"sub": user.id})
    
    return TokenResponse(token=access_token, user=user)

@api_router.post("/auth/login", response_model=TokenResponse)
async def login(credentials: UserLogin):
    # Find user
    user_doc = await db.users.find_one({"email": credentials.email}, {"_id": 0})
    if not user_doc:
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    # Verify password
    if not verify_password(credentials.password, user_doc['password_hash']):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    # Convert ISO string to datetime
    if isinstance(user_doc['created_at'], str):
        user_doc['created_at'] = datetime.fromisoformat(user_doc['created_at'])
    
    user = User(
        id=user_doc['id'],
        email=user_doc['email'],
        name=user_doc['name'],
        created_at=user_doc['created_at']
    )
    
    # Create access token
    access_token = create_access_token(data={"sub": user.id})
    
    return TokenResponse(token=access_token, user=user)

@api_router.get("/auth/me", response_model=User)
async def get_me(current_user: dict = Depends(get_current_user)):
    if isinstance(current_user['created_at'], str):
        current_user['created_at'] = datetime.fromisoformat(current_user['created_at'])
    return User(**current_user)

# ==================== Issue Routes ====================

@api_router.post("/issues", response_model=Issue)
async def create_issue(issue_data: IssueCreate, current_user: dict = Depends(get_current_user)):
    issue = Issue(
        title=issue_data.title,
        description=issue_data.description,
        priority=issue_data.priority,
        user_id=current_user['id'],
        user_name=current_user['name']
    )
    
    issue_dict = issue.model_dump()
    issue_dict['created_at'] = issue_dict['created_at'].isoformat()
    issue_dict['updated_at'] = issue_dict['updated_at'].isoformat()
    
    await db.issues.insert_one(issue_dict)
    
    return issue

@api_router.get("/issues", response_model=List[Issue])
async def get_issues(
    current_user: dict = Depends(get_current_user),
    priority: Optional[str] = None,
    status: Optional[str] = None,
    search: Optional[str] = None
):
    query = {}
    
    if priority:
        query['priority'] = priority
    if status:
        query['status'] = status
    if search:
        query['$or'] = [
            {"title": {"$regex": search, "$options": "i"}},
            {"description": {"$regex": search, "$options": "i"}}
        ]
    
    issues = await db.issues.find(query, {"_id": 0}).sort("created_at", -1).to_list(1000)
    
    # Convert ISO strings back to datetime objects
    for issue in issues:
        if isinstance(issue['created_at'], str):
            issue['created_at'] = datetime.fromisoformat(issue['created_at'])
        if isinstance(issue['updated_at'], str):
            issue['updated_at'] = datetime.fromisoformat(issue['updated_at'])
        for solution in issue.get('solutions', []):
            if isinstance(solution['created_at'], str):
                solution['created_at'] = datetime.fromisoformat(solution['created_at'])
    
    return issues

@api_router.get("/issues/{issue_id}", response_model=Issue)
async def get_issue(issue_id: str, current_user: dict = Depends(get_current_user)):
    issue = await db.issues.find_one({"id": issue_id}, {"_id": 0})
    if not issue:
        raise HTTPException(status_code=404, detail="Issue not found")
    
    # Convert ISO strings back to datetime objects
    if isinstance(issue['created_at'], str):
        issue['created_at'] = datetime.fromisoformat(issue['created_at'])
    if isinstance(issue['updated_at'], str):
        issue['updated_at'] = datetime.fromisoformat(issue['updated_at'])
    for solution in issue.get('solutions', []):
        if isinstance(solution['created_at'], str):
            solution['created_at'] = datetime.fromisoformat(solution['created_at'])
    
    return Issue(**issue)

@api_router.put("/issues/{issue_id}", response_model=Issue)
async def update_issue(
    issue_id: str,
    issue_update: IssueUpdate,
    current_user: dict = Depends(get_current_user)
):
    issue = await db.issues.find_one({"id": issue_id}, {"_id": 0})
    if not issue:
        raise HTTPException(status_code=404, detail="Issue not found")
    
    update_data = issue_update.model_dump(exclude_unset=True)
    update_data['updated_at'] = datetime.now(timezone.utc).isoformat()
    
    await db.issues.update_one({"id": issue_id}, {"$set": update_data})
    
    updated_issue = await db.issues.find_one({"id": issue_id}, {"_id": 0})
    
    # Convert ISO strings back to datetime objects
    if isinstance(updated_issue['created_at'], str):
        updated_issue['created_at'] = datetime.fromisoformat(updated_issue['created_at'])
    if isinstance(updated_issue['updated_at'], str):
        updated_issue['updated_at'] = datetime.fromisoformat(updated_issue['updated_at'])
    for solution in updated_issue.get('solutions', []):
        if isinstance(solution['created_at'], str):
            solution['created_at'] = datetime.fromisoformat(solution['created_at'])
    
    return Issue(**updated_issue)

@api_router.delete("/issues/{issue_id}")
async def delete_issue(issue_id: str, current_user: dict = Depends(get_current_user)):
    result = await db.issues.delete_one({"id": issue_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Issue not found")
    return {"message": "Issue deleted successfully"}

@api_router.post("/issues/{issue_id}/solutions", response_model=Issue)
async def add_solution(
    issue_id: str,
    solution_data: SolutionCreate,
    current_user: dict = Depends(get_current_user)
):
    issue = await db.issues.find_one({"id": issue_id}, {"_id": 0})
    if not issue:
        raise HTTPException(status_code=404, detail="Issue not found")
    
    solution = Solution(
        solution_text=solution_data.solution_text,
        created_by=current_user['id'],
        created_by_name=current_user['name']
    )
    
    solution_dict = solution.model_dump()
    solution_dict['created_at'] = solution_dict['created_at'].isoformat()
    
    await db.issues.update_one(
        {"id": issue_id},
        {
            "$push": {"solutions": solution_dict},
            "$set": {"updated_at": datetime.now(timezone.utc).isoformat()}
        }
    )
    
    updated_issue = await db.issues.find_one({"id": issue_id}, {"_id": 0})
    
    # Convert ISO strings back to datetime objects
    if isinstance(updated_issue['created_at'], str):
        updated_issue['created_at'] = datetime.fromisoformat(updated_issue['created_at'])
    if isinstance(updated_issue['updated_at'], str):
        updated_issue['updated_at'] = datetime.fromisoformat(updated_issue['updated_at'])
    for sol in updated_issue.get('solutions', []):
        if isinstance(sol['created_at'], str):
            sol['created_at'] = datetime.fromisoformat(sol['created_at'])
    
    return Issue(**updated_issue)

@api_router.get("/issues/{issue_id}/similar", response_model=List[Issue])
async def get_similar_issues(issue_id: str, current_user: dict = Depends(get_current_user)):
    # Get the current issue
    issue = await db.issues.find_one({"id": issue_id}, {"_id": 0})
    if not issue:
        raise HTTPException(status_code=404, detail="Issue not found")
    
    # Basic text matching - search for issues with similar title or description
    # This can be enhanced with AI similarity later
    similar_issues = await db.issues.find(
        {
            "id": {"$ne": issue_id},
            "$or": [
                {"title": {"$regex": issue['title'], "$options": "i"}},
                {"description": {"$regex": issue.get('description', ''), "$options": "i"}}
            ]
        },
        {"_id": 0}
    ).limit(5).to_list(5)
    
    # Convert ISO strings back to datetime objects
    for similar_issue in similar_issues:
        if isinstance(similar_issue['created_at'], str):
            similar_issue['created_at'] = datetime.fromisoformat(similar_issue['created_at'])
        if isinstance(similar_issue['updated_at'], str):
            similar_issue['updated_at'] = datetime.fromisoformat(similar_issue['updated_at'])
        for solution in similar_issue.get('solutions', []):
            if isinstance(solution['created_at'], str):
                solution['created_at'] = datetime.fromisoformat(solution['created_at'])
    
    return similar_issues

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
