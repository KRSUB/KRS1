import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'sonner';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Clock, User, Edit, Trash2, CheckCircle, XCircle } from 'lucide-react';
import PriorityBadge from './PriorityBadge';
import StatusBadge from './StatusBadge';

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

export const IssueDrawer = ({ issue, onClose, onIssueUpdated }) => {
  const [loading, setLoading] = useState(false);
  const [similarIssues, setSimilarIssues] = useState([]);
  const [newSolution, setNewSolution] = useState('');
  const [editMode, setEditMode] = useState(false);
  const [editStatus, setEditStatus] = useState('');
  const [currentIssue, setCurrentIssue] = useState(null);

  useEffect(() => {
    if (issue) {
      setCurrentIssue(issue);
      setEditStatus(issue.status);
      fetchSimilarIssues();
    }
  }, [issue]);

  const fetchCurrentIssue = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${API}/issues/${issue.id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setCurrentIssue(response.data);
    } catch (error) {
      console.error('Failed to fetch issue');
    }
  };

  const fetchSimilarIssues = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${API}/issues/${issue.id}/similar`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setSimilarIssues(response.data);
    } catch (error) {
      console.error('Failed to fetch similar issues');
    }
  };

  const handleAddSolution = async () => {
    if (!newSolution.trim()) return;

    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      await axios.post(
        `${API}/issues/${issue.id}/solutions`,
        { solution_text: newSolution },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success('Solution added');
      setNewSolution('');
      await fetchCurrentIssue();
      onIssueUpdated();
    } catch (error) {
      toast.error('Failed to add solution');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      await axios.put(
        `${API}/issues/${issue.id}`,
        { status: editStatus },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success('Status updated');
      setEditMode(false);
      await fetchCurrentIssue();
      onIssueUpdated();
    } catch (error) {
      toast.error('Failed to update status');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to delete this issue?')) return;

    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`${API}/issues/${issue.id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      toast.success('Issue deleted');
      onClose();
      onIssueUpdated();
    } catch (error) {
      toast.error('Failed to delete issue');
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (!issue || !currentIssue) return null;

  return (
    <Sheet open={!!issue} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-xl overflow-y-auto" data-testid="issue-drawer">
        <SheetHeader>
          <div className="flex items-start justify-between mb-4">
            <SheetTitle className="font-heading font-semibold text-2xl flex-1 pr-4" data-testid="drawer-title">
              {currentIssue.title}
            </SheetTitle>
            <PriorityBadge priority={currentIssue.priority} />
          </div>
        </SheetHeader>

        <div className="space-y-6 py-6">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-heading font-semibold text-lg">Status</h3>
              {editMode ? (
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setEditMode(false)}
                    data-testid="cancel-edit-btn"
                  >
                    <XCircle className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    onClick={handleUpdateStatus}
                    disabled={loading}
                    data-testid="save-status-btn"
                  >
                    <CheckCircle className="w-4 h-4 mr-1" />
                    Save
                  </Button>
                </div>
              ) : (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setEditMode(true)}
                  data-testid="edit-status-btn"
                >
                  <Edit className="w-4 h-4" />
                </Button>
              )}
            </div>
            {editMode ? (
              <Select value={editStatus} onValueChange={setEditStatus}>
                <SelectTrigger className="h-10 rounded-lg" data-testid="status-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="open">Open</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="resolved">Resolved</SelectItem>
                </SelectContent>
              </Select>
            ) : (
              <StatusBadge status={currentIssue.status} />
            )}
          </div>

          <div>
            <h3 className="font-heading font-semibold text-lg mb-3">Description</h3>
            <p className="font-sans text-sm leading-relaxed text-muted-foreground" data-testid="drawer-description">
              {currentIssue.description}
            </p>
          </div>

          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <User className="w-4 h-4" />
              <span>{currentIssue.user_name}</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              <span>{formatDate(currentIssue.created_at)}</span>
            </div>
          </div>

          <div className="border-t border-border pt-6">
            <h3 className="font-heading font-semibold text-lg mb-4">Solutions</h3>
            {currentIssue.solutions && currentIssue.solutions.length > 0 ? (
              <div className="space-y-3 mb-4" data-testid="solutions-list">
                {currentIssue.solutions.map((solution, index) => (
                  <div key={solution.id} className="rounded-lg bg-secondary/50 p-4" data-testid={`solution-${index}`}>
                    <p className="font-sans text-sm leading-relaxed mb-2">{solution.solution_text}</p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <User className="w-3 h-3" />
                      <span>{solution.created_by_name}</span>
                      <span>•</span>
                      <span>{formatDate(solution.created_at)}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="font-sans text-sm text-muted-foreground mb-4" data-testid="no-solutions">
                No solutions yet
              </p>
            )}
            <div className="space-y-3">
              <Textarea
                placeholder="Add a solution..."
                value={newSolution}
                onChange={(e) => setNewSolution(e.target.value)}
                className="min-h-[100px] rounded-lg"
                data-testid="solution-input"
              />
              <Button
                onClick={handleAddSolution}
                disabled={loading || !newSolution.trim()}
                className="w-full h-10 rounded-lg"
                data-testid="add-solution-btn"
              >
                Add Solution
              </Button>
            </div>
          </div>

          {similarIssues.length > 0 && (
            <div className="border-t border-border pt-6">
              <h3 className="font-heading font-semibold text-lg mb-4">Similar Issues</h3>
              <div className="space-y-3" data-testid="similar-issues-list">
                {similarIssues.map((similar) => (
                  <div
                    key={similar.id}
                    className="rounded-lg border border-border bg-card p-4 hover:border-primary/50 transition-colors"
                    data-testid={`similar-issue-${similar.id}`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-heading font-medium text-sm flex-1">{similar.title}</h4>
                      <PriorityBadge priority={similar.priority} />
                    </div>
                    <p className="font-sans text-xs text-muted-foreground line-clamp-2 mb-2">
                      {similar.description}
                    </p>
                    {similar.solutions && similar.solutions.length > 0 && (
                      <p className="font-mono text-xs tracking-wide uppercase text-muted-foreground">
                        {similar.solutions.length} {similar.solutions.length === 1 ? 'Solution' : 'Solutions'}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="border-t border-border pt-6">
            <Button
              onClick={handleDelete}
              disabled={loading}
              variant="destructive"
              className="w-full h-10 rounded-lg"
              data-testid="delete-issue-btn"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Delete Issue
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default IssueDrawer;
