import React from 'react';
import { Clock, User } from 'lucide-react';
import PriorityBadge from './PriorityBadge';
import StatusBadge from './StatusBadge';

export const IssueCard = ({ issue, onClick }) => {
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  return (
    <div
      onClick={onClick}
      className="group relative overflow-hidden rounded-xl border border-border bg-card p-5 hover:border-primary/50 transition-colors cursor-pointer"
      data-testid={`issue-card-${issue.id}`}
    >
      <div className="flex items-start justify-between mb-3">
        <h3 className="font-heading font-semibold text-lg leading-tight flex-1 pr-2" data-testid="issue-title">
          {issue.title}
        </h3>
        <PriorityBadge priority={issue.priority} />
      </div>

      <p className="font-sans text-sm text-muted-foreground mb-4 line-clamp-2" data-testid="issue-description">
        {issue.description}
      </p>

      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1">
            <User className="w-3 h-3" />
            <span>{issue.user_name}</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span>{formatDate(issue.created_at)}</span>
          </div>
        </div>
        <StatusBadge status={issue.status} />
      </div>

      {issue.solutions && issue.solutions.length > 0 && (
        <div className="mt-3 pt-3 border-t border-border">
          <p className="font-mono text-xs tracking-wide uppercase text-muted-foreground">
            {issue.solutions.length} {issue.solutions.length === 1 ? 'Solution' : 'Solutions'}
          </p>
        </div>
      )}
    </div>
  );
};

export default IssueCard;
