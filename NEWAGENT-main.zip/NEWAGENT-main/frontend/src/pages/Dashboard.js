import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { LogOut, Plus, Search, Filter } from 'lucide-react';
import CreateIssueDialog from '@/components/CreateIssueDialog';
import IssueCard from '@/components/IssueCard';
import IssueDrawer from '@/components/IssueDrawer';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

export default function Dashboard({ user, onLogout }) {
  const [issues, setIssues] = useState([]);
  const [filteredIssues, setFilteredIssues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedIssue, setSelectedIssue] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  const fetchIssues = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${API}/issues`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setIssues(response.data);
      setFilteredIssues(response.data);
    } catch (error) {
      toast.error('Failed to fetch issues');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchIssues();
  }, []);

  useEffect(() => {
    let filtered = [...issues];

    if (searchQuery) {
      filtered = filtered.filter(
        (issue) =>
          issue.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          issue.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (priorityFilter !== 'all') {
      filtered = filtered.filter((issue) => issue.priority === priorityFilter);
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter((issue) => issue.status === statusFilter);
    }

    setFilteredIssues(filtered);
  }, [searchQuery, priorityFilter, statusFilter, issues]);

  const handleIssueCreated = () => {
    fetchIssues();
    setShowCreateDialog(false);
  };

  const handleIssueUpdated = () => {
    fetchIssues();
  };

  const stats = {
    total: issues.length,
    open: issues.filter((i) => i.status === 'open').length,
    inProgress: issues.filter((i) => i.status === 'in-progress').length,
    resolved: issues.filter((i) => i.status === 'resolved').length,
  };

  return (
    <div className="min-h-screen bg-background" data-testid="dashboard">
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div>
            <h1 className="font-heading font-bold text-2xl tracking-tight" data-testid="dashboard-title">
              Viber Issue
            </h1>
            <p className="font-sans text-sm text-muted-foreground">Vibe coding Issue traker - Welcome, {user.name}</p>
          </div>
          <Button
            onClick={onLogout}
            variant="ghost"
            className="rounded-md hover:bg-muted"
            data-testid="logout-btn"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-8">
          <div className="rounded-2xl bg-secondary/50 p-6 border-none" data-testid="stat-total">
            <p className="font-mono text-sm tracking-wide uppercase text-muted-foreground mb-1">Total Issues</p>
            <p className="font-heading font-bold text-3xl">{stats.total}</p>
          </div>
          <div className="rounded-2xl bg-secondary/50 p-6 border-none" data-testid="stat-open">
            <p className="font-mono text-sm tracking-wide uppercase text-muted-foreground mb-1">Open</p>
            <p className="font-heading font-bold text-3xl text-blue-600">{stats.open}</p>
          </div>
          <div className="rounded-2xl bg-secondary/50 p-6 border-none" data-testid="stat-progress">
            <p className="font-mono text-sm tracking-wide uppercase text-muted-foreground mb-1">In Progress</p>
            <p className="font-heading font-bold text-3xl text-yellow-600">{stats.inProgress}</p>
          </div>
          <div className="rounded-2xl bg-secondary/50 p-6 border-none" data-testid="stat-resolved">
            <p className="font-mono text-sm tracking-wide uppercase text-muted-foreground mb-1">Resolved</p>
            <p className="font-heading font-bold text-3xl text-green-600">{stats.resolved}</p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="Search issues..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-12 pl-10 rounded-lg"
              data-testid="search-input"
            />
          </div>
          <Select value={priorityFilter} onValueChange={setPriorityFilter}>
            <SelectTrigger className="w-full sm:w-[180px] h-12 rounded-lg" data-testid="priority-filter">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Priority" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Priorities</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="low">Low</SelectItem>
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-[180px] h-12 rounded-lg" data-testid="status-filter">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="open">Open</SelectItem>
              <SelectItem value="in-progress">In Progress</SelectItem>
              <SelectItem value="resolved">Resolved</SelectItem>
            </SelectContent>
          </Select>
          <Button
            onClick={() => setShowCreateDialog(true)}
            className="h-12 rounded-full px-6 font-semibold shadow-lg hover:shadow-xl transition-all"
            data-testid="create-issue-btn"
          >
            <Plus className="w-5 h-5 mr-2" />
            New Issue
          </Button>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          </div>
        ) : filteredIssues.length === 0 ? (
          <div className="text-center py-20" data-testid="no-issues">
            <p className="font-sans text-lg text-muted-foreground">
              {searchQuery || priorityFilter !== 'all' || statusFilter !== 'all'
                ? 'No issues match your filters'
                : 'No issues yet. Create your first one!'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" data-testid="issues-grid">
            {filteredIssues.map((issue) => (
              <IssueCard key={issue.id} issue={issue} onClick={() => setSelectedIssue(issue)} />
            ))}
          </div>
        )}
      </div>

      <CreateIssueDialog
        open={showCreateDialog}
        onClose={() => setShowCreateDialog(false)}
        onIssueCreated={handleIssueCreated}
      />

      <IssueDrawer
        issue={selectedIssue}
        onClose={() => setSelectedIssue(null)}
        onIssueUpdated={handleIssueUpdated}
      />
    </div>
  );
}
