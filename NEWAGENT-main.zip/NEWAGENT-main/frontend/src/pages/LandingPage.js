import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { AlertCircle, CheckCircle, TrendingUp } from 'lucide-react';

export default function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      <div
        className="relative min-h-screen flex items-center justify-center overflow-hidden"
        style={{
          backgroundImage: `linear-gradient(rgba(222, 47%, 11%, 0.85), rgba(222, 47%, 11%, 0.85)), url('https://images.unsplash.com/photo-1763251177167-85a9ca1966a8?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NTY2NzV8MHwxfHNlYXJjaHwyfHxtaW5pbWFsaXN0JTIwYWJzdHJhY3QlMjBvZmZpY2UlMjBnZW9tZXRyeXxlbnwwfHx8fDE3NjYwNTQxNjd8MA&ixlib=rb-4.1.0&q=85')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="relative z-10 max-w-5xl mx-auto px-6 py-16 text-center">
          <h1 className="font-heading font-bold text-5xl sm:text-6xl lg:text-7xl tracking-tight text-primary-foreground mb-6" data-testid="hero-title">
            Viber Issue
          </h1>
          <p className="font-sans text-lg sm:text-xl text-primary-foreground/90 mb-10 max-w-2xl mx-auto" data-testid="hero-subtitle">
            Vibe coding Issue traker
          </p>
          <Button
            data-testid="get-started-btn"
            onClick={() => navigate('/auth')}
            size="lg"
            className="rounded-full px-8 py-6 text-lg font-semibold shadow-lg hover:shadow-xl transition-all active:scale-95 bg-background text-foreground hover:bg-background/90"
          >
            Get Started
          </Button>
        </div>
      </div>

      <section className="py-20 px-6 bg-secondary/50">
        <div className="max-w-6xl mx-auto">
          <h2 className="font-heading font-semibold text-3xl sm:text-4xl tracking-tight text-center mb-16" data-testid="features-title">
            Built for Support Teams
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="rounded-2xl bg-card p-8 border-none shadow-sm" data-testid="feature-track">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <AlertCircle className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-heading font-semibold text-xl mb-3">Issue Posting</h3>
              <p className="font-sans text-base leading-relaxed text-muted-foreground">
                Create and track customer issues with priority levels, detailed descriptions, and status updates.
              </p>
            </div>
            <div className="rounded-2xl bg-card p-8 border-none shadow-sm" data-testid="feature-search">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <CheckCircle className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-heading font-semibold text-xl mb-3">Solution Tracking</h3>
              <p className="font-sans text-base leading-relaxed text-muted-foreground">
                Document solutions for each issue and build a knowledge base of proven fixes.
              </p>
            </div>
            <div className="rounded-2xl bg-card p-8 border-none shadow-sm" data-testid="feature-similar">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <TrendingUp className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-heading font-semibold text-xl mb-3">Smart Search</h3>
              <p className="font-sans text-base leading-relaxed text-muted-foreground">
                Find similar issues quickly and discover what solutions have worked before.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
